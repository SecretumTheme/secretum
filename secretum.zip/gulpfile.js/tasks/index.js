/**
 * Make an index.js in a directory with this code to clean things up:
 * @source https://github.com/aseemk/requireDir
 */
module.exports = require('require-dir')(); // defaults to '.'