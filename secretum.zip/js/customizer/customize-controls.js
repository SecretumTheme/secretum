/**
 * Custom Customizer Controls
 *
 * @package Secretum
 */

( function( $ ) {
	wp.customize.bind( 'ready', function() {
		var customize = this;
		// Codes here.
	} );
} )( jQuery );
