<?php
/**
 * Panels, Sections, & Settings
 *
 * @package    Secretum
 * @subpackage Core\Customize\Sections\Featured-Image
 * @author     SecretumTheme <author@secretumtheme.com>
 * @copyright  2018-2019 Secretum
 * @license    https://github.com/SecretumTheme/secretum/blob/master/license.txt GPL-2.0
 * @link       https://github.com/SecretumTheme/secretum/blob/master/inc/customize/sections/featured-image.php
 * @since      1.0.0
 */

namespace Secretum;

// Panel.
$customizer->panel(
	'featured_image',
	__( 'Featured Image', 'secretum' )
);


// Section.
$customizer->section(
	'featured_image_display',
	'featured_image',
	__( 'Display Settings', 'secretum' ),
	''
);


// Checkbox.
$customizer->checkbox(
	'featured_image_display',
	'featured_image_status',
	__( 'Disable Featured Images', 'secretum' ),
	'',
	$defaults['featured_image_status']
);


// Select.
$customizer->select(
	'featured_image_display',
	'featured_image_display_location',
	__( 'Featured Image Display Location', 'secretum' ),
	'',
	$defaults['featured_image_display_location'],
	[
		'' 					=> __( 'Theme Default', 'secretum' ),
		'before_content' 	=> __( 'Before Post Title', 'secretum' ),
		'before_entry' 		=> __( 'Before Post Content', 'secretum' ),
		'after_header' 		=> __( 'After Theme Header Area', 'secretum' ),
	]
);


// Wrapper.
$wrapper->settings( [
	'section' => 'featured_image',
] );


// Wrapper Borders.
$borders->settings( [
	'section' => 'featured_image_wrapper',
] );


// Container.
$container->settings( [
	'section' 	=> 'featured_image',
	'type' 		=> false,
] );


// Container Borders.
$borders->settings( [
	'section' => 'featured_image_container',
] );
