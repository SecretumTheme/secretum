<?php
/**
 * Related Products
 *
 * @package 	Secretum
 * @subpackage 	Theme\WooCommerce\Single-Product
 * @author 		SecretumTheme <author@secretumtheme.com>
 * @copyright 	2018-2019 Secretum
 * @version     3.0.0
 * @license 	https://github.com/SecretumTheme/secretum/blob/master/license.txt GPL-2.0
 * @link 		https://github.com/SecretumTheme/secretum/blob/master/woocommerce/single-product/related.php
 * @since 		1.0.0
 */

namespace Secretum;

if ( $related_products ) {
?>
<section class="related products">
	<h2><?php esc_html_e( 'Related products', 'secretum' ); ?></h2>
	<?php woocommerce_product_loop_start(); ?>
		<?php foreach ( $related_products as $related_product ) { ?>
			<?php
				setup_postdata( get_post( $related_product->get_id() ) );
				wc_get_template_part( 'content', 'product' ); ?>
		<?php } ?>
	<?php woocommerce_product_loop_end(); ?>
</section>
<?php
}

wp_reset_postdata();
